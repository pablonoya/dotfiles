var plasma = getApiVersion(1);

var layout = {
    "desktops": [
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "0",
                    "wallpaperplugin": "org.kde.image"
                },
                "/ConfigDialog": {
                    "DialogHeight": "452",
                    "DialogWidth": "902"
                },
                "/Configuration": {
                    "PreloadWeight": "0"
                },
                "/General": {
                    "ToolBoxButtonState": "top",
                    "ToolBoxButtonX": "1328",
                    "arrangement": "1",
                    "pressToMoveHelp": "false",
                    "previewPlugins": "appimagethumbnail,audiothumbnail,textthumbnail,fontthumbnail,ffmpegthumbs,djvuthumbnail,directorythumbnail,kraorathumbnail,opendocumentthumbnail,windowsexethumbnail,imagethumbnail,windowsimagethumbnail,exrthumbnail,jpegthumbnail,svgthumbnail,comicbookthumbnail,mltpreview",
                    "sortMode": "-1",
                    "textLines": "3",
                    "toolTips": "true",
                    "url": "activities:/current/"
                },
                "/Wallpaper/General": {
                    "Color": "invalid",
                    "FillMode": "2",
                    "SlideInterval": "1",
                    "SlidePaths": "\\0"
                },
                "/Wallpaper/org.kde.image/General": {
                    "Blur": "true",
                    "Color": "invalid",
                    "FillMode": "2",
                    "Image": "file:///home/pablo/Imágenes/Projects/new_Notellia.png",
                    "SlideInterval": "1"
                },
                "/Wallpaper/org.kde.potd/General": {
                    "Color": "invalid",
                    "FillMode": "2"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        },
        {
            "applets": [
            ],
            "config": {
                "/": {
                    "formfactor": "0",
                    "immutability": "1",
                    "lastScreen": "1",
                    "wallpaperplugin": "org.kde.image"
                },
                "/Configuration": {
                    "PreloadWeight": "0"
                }
            },
            "wallpaperPlugin": "org.kde.image"
        }
    ],
    "panels": [
    ],
    "serializationFormatVersion": "1"
}
;

plasma.loadSerializedLayout(layout);
